In this assignment we perfirmed the various 

gcc-gimple commands.
