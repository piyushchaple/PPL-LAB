#include <stdio.h>

//Compiler version gcc  6.3.0

int main()
{
  int a=12;
  int b=15;
  int c=23;
  int p;
  p=a+b*c;
  printf("%d",p);
  return 0;
}
